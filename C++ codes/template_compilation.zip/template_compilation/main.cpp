#include <iostream>
#include "foo.hpp"

using namespace std;
int main(void){
    foo<int>(1);
}