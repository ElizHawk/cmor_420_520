template <typename T> void foo(T x);

#include "foo.tpp"